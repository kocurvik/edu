I = rgb2gray(imread('leopard.jpg'));

w = 2:1:6;
w = w.^1.5;

o = 0:15:90;

bank = gabor(w, o);

[mag, phase] = imgaborfilt(I, bank);
figure;
for i = 1:size(mag,3)
    imagesc(mag(:,:,i))
    waitforbuttonpress;
end

