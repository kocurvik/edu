I = imread('ciary.jpg');
G = rgb2gray(I);
BW = imbinarize(G);
imagesc(BW)
[H, t, r] = hough(BW);
P = houghpeaks(H,50);
L = houghlines(BW,t,r,P);

imshow(I);
hold on
for i = 1:50    
    xy = [L(i).point1; L(i).point2];
    plot(xy(:,1),xy(:,2),'LineWidth',2);
end
hold off