function thresholds = compute_thresholds()
    % funkcia vr�ti vektor prahov pre zvolen� pr�znaky
    thresholds = [];

    % paintings a photographs s� bunky (cell), ktor� obsahuj� jednotliv�
    % obr�zky, na?�tan� cez imread, t.j. uint8
    % k obr�zkom sa d� prist�pi? takto: paingings{4} at?.
    paintings = load_database('Database/Painting');
    photographs = load_database('Database/Photograph');
    

    % v tele hlavnej funkcie m��ete vola?  lok�lne funkcie napr.
    % mulitply_by_2 ktor� je definovan� ni��ie

    % m = multiply_by_2(4);
    
    % eventu�lne si m��ete vytvori? navy�e m-file, nezabudnite ho ale
    % posla? spolu v r�mci rie�enia
end
    
% lok�lne funkcie sa vytvaraj� za ukon?enou hlavnou funkciou
% function multiplied = multiply_by_2(x)
%     multiplied = x*2;
% end




