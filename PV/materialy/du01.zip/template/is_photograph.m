function ret = is_photograph(image,thresholds)
    % vr�ti true ak je obr�zok fotografia, t.j. aspo? 2 pr�znaky s� na tej 
    % strane prahu, kde sme ur?ili, �e s� fotky 
    ret = 1;
end