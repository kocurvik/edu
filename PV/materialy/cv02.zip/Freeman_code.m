function r=Freeman_code(B)

[w,h]=size(B);
r=zeros(1,w-1);
for i=1:w-1
    if B(i,1)==B(i+1,1) && B(i,2)>B(i+1,2) 
        r(i)=4; 
    end;
    if B(i,1)>B(i+1,1) && B(i,2)>B(i+1,2) 
        r(i)=3; 
    end;    
    if B(i,1)>B(i+1,1) && B(i,2)==B(i+1,2) 
        r(i)=2; 
    end;
    if B(i,1)>B(i+1,1) && B(i,2)<B(i+1,2) 
        r(i)=1; 
    end;
    if B(i,1)==B(i+1,1) && B(i,2)<B(i+1,2) 
        r(i)=0; 
    end;
    if B(i,1)<B(i+1,1) && B(i,2)<B(i+1,2) 
        r(i)=7; 
    end;
    if B(i,1)<B(i+1,1) && B(i,2)==B(i+1,2) 
        r(i)=6; 
    end;
    if B(i,1)<B(i+1,1) && B(i,2)>B(i+1,2) 
        r(i)=5; 
    end;
end