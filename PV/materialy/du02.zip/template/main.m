function varargout = main(varargin)
% MAIN MATLAB code for main.fig
%      MAIN, by itself, creates a new MAIN or raises the existing
%      singleton*.
%
%      H = MAIN returns the handle to a new MAIN or the handle to
%      the existing singleton*.
%
%      MAIN('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MAIN.M with the given input arguments.
%
%      MAIN('Property','Value',...) creates a new MAIN or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before main_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to main_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help main

% Last Modified by GUIDE v2.5 14-Nov-2018 01:45:31

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @main_OpeningFcn, ...
                   'gui_OutputFcn',  @main_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before main is made visible.
function main_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to main (see VARARGIN)

% Choose default command line output for main
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes main wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = main_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in loadObject.
function loadObject_Callback(hObject, eventdata, handles)
% hObject    handle to loadObject (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[i_file,i_PathName] = uigetfile({'*.jpg;*.png;*.bmp','All Image Files';...
          '*.*','All Files' });
if ~isequal(i_file, 0)
    % Reading the Image file
    i_file = fullfile(i_PathName,i_file);
    image = imread(i_file);
    set(handles.objectAxes,'Visible','on');
    imshow(image, 'Parent', handles.objectAxes);
    set(handles.loadObject,'UserData',image);    
end

% --- Executes on button press in loadImage.
function loadImage_Callback(hObject, eventdata, handles)
% hObject    handle to loadImage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[i_file,i_PathName] = uigetfile({'*.jpg;*.png;*.bmp','All Image Files';...
          '*.*','All Files' });
if ~isequal(i_file, 0)
    % Reading the Image file
    i_file = fullfile(i_PathName,i_file);
    image = imread(i_file);
    set(handles.imageAxes,'Visible','on');
    imshow(image, 'Parent', handles.imageAxes);
    set(handles.loadImage,'UserData',image);
end


% --- Executes on button press in saliencyButton.
function saliencyButton_Callback(hObject, eventdata, handles)
% hObject    handle to saliencyButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
o_img = get(handles.loadObject,'UserData');
s_img = get(handles.loadImage,'UserData');
s_map = generate_saliency_map(o_img,s_img, get(handles.sliderW,'Value'));
set(handles.saliencyAxes,'Visible','on');
imagesc(s_map, 'Parent', handles.saliencyAxes);
set(handles.saliencyAxes,'xtick',[]);
set(handles.saliencyAxes,'ytick',[]);

% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over loadObject.
function loadObject_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to loadObject (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[i_file,i_PathName] = uigetfile({'*.jpg;*.png;*.bmp','All Image Files';...
          '*.*','All Files' });
if ~isequal(i_file, 0)
    % Reading the Image file
    i_file = fullfile(i_PathName,i_file);
    image = imread(i_file);
    set(handles.objectAxes,'Visible','on');
    imshow(image, 'Parent', handles.objectAxes);
    set(handles.loadObject,'UserData',image);
end


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over loadImage.
function loadImage_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to loadImage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[i_file,i_PathName] = uigetfile({'*.jpg;*.png;*.bmp','All Image Files';...
          '*.*','All Files' });
if ~isequal(i_file, 0)
    % Reading the Image file
    i_file = fullfile(i_PathName,i_file);
    image = imread(i_file);
    set(handles.imageAxes,'Visible','on');
    imshow(image, 'Parent', handles.imageAxes);
    set(handles.loadImage,'UserData',image);
end


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over saliencyButton.
function saliencyButton_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to saliencyButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
o_img = get(handles.loadObject,'UserData');
s_img = get(handles.loadImage,'UserData');
set(handles.saliencyAxes,'Visible','on');
s_map = generate_saliency_map(o_img,s_img, get(handles.sliderW,'Value'));
imagesc(s_map, 'Parent', handles.saliencyAxes);
set(handles.saliencyAxes,'xtick',[]);
set(handles.saliencyAxes,'ytick',[]);


% --- Executes on slider movement.
function sliderW_Callback(hObject, eventdata, handles)
% hObject    handle to sliderW (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function sliderW_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sliderW (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end
