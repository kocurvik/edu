function s_map = generate_saliency_map(o_img, s_img, w)
    % funkcia vr�ti mapu v�znam�ch oblast� v obr�zku o_img ak je sledovan�
    % objekt z s_img, w je hodnota v�hy pre spojenie m�p
    
    % toto je nutn� aby nemuseli skripty by? v tej istej zlo�ke
    addpath('lib')
    
    % vo funkcnej verzii sa do s_map zapise mapa vyznamnych oblasti        
    s_map = zeros(size(o_img));
end