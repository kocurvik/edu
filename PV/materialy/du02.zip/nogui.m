% I = imread('images\skryta.jpg');
% I = imread('images\spajza.jpg');
I = imread('images\spajza2.jpg');

O = imread('images\kava.jpg');

M = generate_saliency_map(O, I, 0.5);
imagesc(M);

M = generate_saliency_map(O, I, 0.0);
figure;
imagesc(M);

M = generate_saliency_map(O, I, 1.0);
figure;
imagesc(M);