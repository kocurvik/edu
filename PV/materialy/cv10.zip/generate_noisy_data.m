function X = generate_noisy_data(n, p, sigma)
    nl = min(round(p * n), n);
    nn = n - nl;
    
    Xn = 2 * rand(nn, 2) - 1;
    
    disp('Generating random data');
    
    r = rand() - 0.5;
    theta = rand() * 2 * pi;
    
    while sin(theta) == 0
        theta = rand() * 2 * pi;
    end
    
    
    m = -cos(theta) / sin(theta);
    k = r / sin(theta);
    
%     max_x = max(1 - q / m, -1 - q / m)
%     min_x = min(1 - q / m, -1 - q / m)
    
    max_x = min(max((1 - k)/m, (-1 - k)/m), 1);
    min_x = max(min((1 - k)/m, (-1 - k)/m), -1);

    Xl = rand(nl, 1) * (max_x - min_x) + min_x;
    Xl(:, 2) = m * Xl + k;
    
    Xl = Xl + sigma * randn(size(Xl));
    Xl(Xl > 1) = 1;
    Xl(Xl < -1) = -1;
    
    figure;
    line_x = linspace(min_x, max_x, 1000);
    plot(line_x, m * line_x + k, 'k-');    
    hold on;
    scatter(Xl(:, 1), Xl(:, 2), 'r.');
    scatter(Xn(:, 1), Xn(:, 2), 'b.');
    hold off;

    fprintf( 'GT m: %f, GT k: %f \n', m, k);
    
    X = cat(1, Xl, Xn);
    X = X(randperm(size(X, 1)), :);
end

