function display_line(X, m, k)
    figure;
    scatter(X(:, 1), X(:, 2), 'b.');
    hold on;
    max_x = min(max((1 - k)/m, (-1 - k)/m), 1);
    min_x = max(min((1 - k)/m, (-1 - k)/m), -1);
    line_x = linspace(min_x, max_x, 1000);    
    plot(line_x, m * line_x + k, 'k-');  
    hold off;
end