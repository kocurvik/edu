I = imread('leopard.jpg');
I = imresize(I,0.25);
A = rgb2gray(I);

imageSize = size(A);
numRows = imageSize(1);
numCols = imageSize(2);

wavelengthMin = 4/sqrt(2);
wavelengthMax = hypot(numRows,numCols);
n = floor(log2(wavelengthMax/wavelengthMin));
wavelength = 2.^(0:(n-2)) * wavelengthMin;

gabor_bank = gabor(wavelength,0:30:150);
[mag, phase] = imgaborfilt(A,gabor_bank);

for i = 1:length(gabor_bank)
    sigma = 0.5*gabor_bank(i).Wavelength;
    K = 3;
    mag(:,:,i) = imgaussfilt(mag(:,:,i),K*sigma); 
end

X = 1:numCols;
Y = 1:numRows;
[X,Y] = meshgrid(X,Y);
featureSet = cat(3,mag,X);
featureSet = cat(3,featureSet,Y);

% featureSet = mag;

numPoints = numRows*numCols;
X = reshape(featureSet,numRows*numCols,[]);

X = bsxfun(@minus, X, mean(X));
X = bsxfun(@rdivide,X,std(X));

coeff = pca(X);
feature2DImage = reshape(X*coeff(:,1),numRows,numCols);
figure
imshow(feature2DImage,[])

L = kmeans(X,2,'Replicates',5);

L = reshape(L,[numRows numCols]);
figure
imshow(label2rgb(L))


Aseg1 = zeros(size(I),'like',I);
Aseg2 = zeros(size(I),'like',I);
BW = L == 2;
BW = repmat(BW,[1 1 3]);
Aseg1(BW) = I(BW);
Aseg2(~BW) = I(~BW);
figure
imshowpair(Aseg1,Aseg2,'montage');
