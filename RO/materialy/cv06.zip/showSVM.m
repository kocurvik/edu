function r = showSVM(SVMModel, X, y)
    svInd = SVMModel.IsSupportVector;
    h = 0.1; % Mesh grid step size
    [X1,X2] = meshgrid(min(X(:,1)):h:max(X(:,1)),...
        min(X(:,2)):h:max(X(:,2)));
    [~,score] = predict(SVMModel,[X1(:),X2(:)]);
    scoreGrid = reshape(score(:,1),size(X1,1),size(X1,2));

    cl = sign(scoreGrid);
    gscatter(X1(:),X2(:),cl(:),...
    [0.1 0.5 0.5; 0.5 0.1 0.5]);
    hold on;
    gscatter(X(:,1),X(:,2),y)
    plot(X(svInd,1),X(svInd,2),'ro','MarkerSize',10)
%     contour(X1,X2,scoreGrid)
%     colorbar;
    hold off
end