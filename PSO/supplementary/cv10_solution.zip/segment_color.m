I = im2double(imread('zatisie.jpg'));
I = imgaussfilt(I,4);

imshow(I);
[x, y] = ginput(1);

I = rgb2lab(I);
c = I(round(y), round(x), :);

D = sqrt(sum((I - c).^2, 3));

imagesc(D)

L = D < 20;
figure;
imshow(L)
