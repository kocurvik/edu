I = im2double(imread('zatisie.jpg'));
I = imgaussfilt(I,4);

% I = rgb2lab(I);

cols = size(I,2);
rows = size(I,1);

% V = reshape(I, rows*cols, 3);

[C, R] = meshgrid(1:cols, 1:rows);
V = cat(3, 5*rgb2lab(I), R, C);
% V = cat(3, 2000*rgb2lab(I), R, C);
V = reshape(V, rows*cols, 5);

km = kmeans(V, 10);

L = reshape(km, [rows, cols]);

% L = zeros(size(C));
% for i = 1:size(V,1)
%     L(V(i,4), V(i,5)) = km(i);
% end

% imagesc(L)
imshow(label2rgb(L))
% imshow(label2rgb(reshape(km,[rows, cols])))