function H = butterhigh(I,d,n)
    rows = size(I,1);
    cols = size(I,2);
    r = linspace(-1,1,rows);
    c = linspace(-1,1,cols);
    [R,C] = meshgrid(c,r);

    B = sqrt(2) - 1;
    D = sqrt(R.^2 + C.^2); 
    H = 1 ./ (1 + B * ((d ./ D).^(2 * n)));
end